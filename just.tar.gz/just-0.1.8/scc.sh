scc --exclude-dir="deps,config,.devcontainer,.git,.vscode" --include-ext="cc,h,js" --wide
